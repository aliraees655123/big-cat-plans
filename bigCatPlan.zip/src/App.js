import logo from './logo.svg';
import './App.css';
import Practice from './Practice';
import Roadmap from './Components/Roadmap/Roadmap';

function App() {
  return (
    <>
    <Roadmap/>


    </>
  );
}

export default App;
