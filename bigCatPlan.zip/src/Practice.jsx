import React, { useEffect, useState,useRef,useCallback } from "react";
import { useWindowScroll } from "react-use";

const Practice = () => {
    // const listInnerRef = useRef();
    
    const [scrolled, setScrolled] = useState(0);

    // const [y, setY] = useState(window.scrollY);

    // const handleNavigation = useCallback(
    //   (e) => {
    //     const window = e.currentTarget;
    //     if (y > window.scrollY) {
    //         setScrolled(scrolled-1);
    //     } else if (y < window.scrollY) {
    //       setScrolled(scrolled+1);
    //     }
    //     setY(window.scrollY);
    //   },
    //   [y]
    // );
  
    // useEffect(() => {
    //   setY(window.scrollY);
    //   window.addEventListener("scroll", handleNavigation);
  
    //   return () => {
    //     window.removeEventListener("scroll", handleNavigation);
    //   };
    // }, [handleNavigation]);

    // console.log("scrolled",scrolled)

    // const onScroll = () => {
    //     if (listInnerRef.current) {
    //       const { scrollTop, scrollHeight, clientHeight } = listInnerRef.current;
    //       if (scrollTop + clientHeight === scrollHeight) {
    //         console.log("reached bottom");
    //       }
    //     }
    //   };



    const { x, y } = useWindowScroll();


    useEffect(() => {
        const height =
            document.documentElement.scrollHeight -
            document.documentElement.clientHeight;
        setScrolled((y / height) * 100);
        console.log("height",height);
        console.log("y",y);

    }, [y]);
    // const changeBackground = () => {
    //     if (window.scrollY == true) {
    //         setScrolled(10);
          
    //     } else {
         
    //         setScrolled(0);
    //     }
    //   };
    //   window.addEventListener("scroll", changeBackground);

    console.log("scrolled",scrolled);

    return (
//         <>
        
//             <div className="top">

//             </div>
// <div className="scrollDivTop" style={{height:"800px"}}>
//             <div className="scrollDiv"
       
//             style={{  overflowY: "auto",height:`${scrolled}%`, background:"red",width:"30px" }}
//             >

//             </div>

//             </div>


        
//         </>
        // <div className="topDiv">
        <div className="scroll-container">
            <div className="indicator" style={{ height: `${scrolled}%` }}></div>
          {/* {scrolled<=40 &&  <div className="indicator" style={{ height: `${scrolled}%` }}></div>} */}

            {/* <div className="indicator" style={{ height: `${scrolled}%` }}></div> */}
        {/* </div> */}
        </div>
    );
};

export default Practice;